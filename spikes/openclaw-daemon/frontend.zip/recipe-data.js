/**
 * 初序 · 五行菜谱数据库
 * 每个五行属性 10 道菜，共 50 道
 * 数据来源：中医食疗经典 + 现代营养学交叉整理
 */

// eslint-disable-next-line no-unused-vars
const RECIPE_DATABASE = {

    /* ═══════════════ 木 · 肝 · 酸味 ═══════════════ */
    wood: [
        {
            name: '醋溜白菜',
            effect: '疏肝理气，开胃消食',
            ingredients: ['大白菜 半棵', '陈醋 2勺', '干辣椒 3个', '花椒少许'],
            steps: ['白菜洗净切块', '热锅爆花椒干辣椒', '下白菜大火翻炒', '加醋调味出锅'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '菠菜猪肝汤',
            effect: '补肝养血，明目润燥',
            ingredients: ['新鲜菠菜 200g', '猪肝 150g', '姜丝适量', '枸杞 10粒'],
            steps: ['猪肝切片用料酒腌制去腥', '水开后下姜丝和猪肝煮2分钟', '加入菠菜煮30秒', '撒枸杞调盐出锅'],
            season: '春季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '凉拌芹菜花生',
            effect: '平肝降压，清热利湿',
            ingredients: ['芹菜 300g', '花生米 100g', '蒜末适量', '香醋 2勺'],
            steps: ['花生米油炸至金黄捞出', '芹菜焯水过凉切段', '加蒜末香醋生抽拌匀', '撒上花生米即可'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '猕猴桃酸奶杯',
            effect: '滋阴柔肝，助消化',
            ingredients: ['猕猴桃 2个', '原味酸奶 200ml', '燕麦片 30g', '蜂蜜适量'],
            steps: ['猕猴桃去皮切丁', '杯底铺一层燕麦', '倒入酸奶铺平', '摆上猕猴桃淋蜂蜜'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '西红柿炒鸡蛋',
            effect: '养肝明目，生津止渴',
            ingredients: ['西红柿 2个', '鸡蛋 3个', '葱花适量', '白糖 1小勺'],
            steps: ['鸡蛋打散炒熟盛出', '番茄切块炒出汁', '倒回鸡蛋翻炒均匀', '加糖盐调味撒葱花'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '山楂雪梨茶',
            effect: '消食化积，疏肝解郁',
            ingredients: ['干山楂 10片', '雪梨 1个', '冰糖适量', '清水 800ml'],
            steps: ['雪梨去核切块', '山楂洗净与梨一起入锅', '加水大火烧开转小火煮15分钟', '加冰糖搅匀即可'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '韭菜鸡蛋饺',
            effect: '温肝补阳，暖胃散寒',
            ingredients: ['韭菜 200g', '鸡蛋 2个', '饺子皮 30张', '虾皮 20g'],
            steps: ['鸡蛋炒碎放凉', '韭菜切碎加虾皮拌馅', '包成饺子', '水开下锅煮至浮起即熟'],
            season: '春季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '枸杞菊花茶',
            effect: '清肝明目，养阴润燥',
            ingredients: ['枸杞 15粒', '杭白菊 5朵', '冰糖适量', '热水 300ml'],
            steps: ['枸杞和菊花放入杯中', '注入90度热水', '加盖焖泡5分钟', '加冰糖调味饮用'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '香椿拌豆腐',
            effect: '疏肝和胃，清热解毒',
            ingredients: ['香椿芽 100g', '北豆腐 1块', '香油 1勺', '盐适量'],
            steps: ['香椿焯水切碎', '豆腐切小丁焯水沥干', '香椿碎铺在豆腐上', '淋香油加盐拌匀'],
            season: '春季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '青梅汁',
            effect: '敛肝止渴，生津開胃',
            ingredients: ['青梅 500g', '冰糖 300g', '清水 1000ml'],
            steps: ['青梅洗净去核', '与冰糖一起放入锅中', '加水煮沸转小火熬20分钟', '放凉过滤即可冷藏饮用'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        }
    ],

    /* ═══════════════ 火 · 心 · 苦味 ═══════════════ */
    fire: [
        {
            name: '苦瓜酿肉',
            effect: '清热解毒，养心安神',
            ingredients: ['苦瓜 2根', '猪肉馅 200g', '葱姜蒜适量', '生抽 1勺'],
            steps: ['苦瓜切段去瓤', '肉馅调味后填入', '上锅蒸15分钟', '淋上蒸鱼豉油即可'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '莲子百合银耳羹',
            effect: '养心安神，润肺清热',
            ingredients: ['莲子 30g', '百合 20g', '银耳 半朵', '冰糖适量'],
            steps: ['银耳提前泡发撕小朵', '莲子去心与银耳同煮30分钟', '加入百合煮10分钟', '放冰糖搅匀即可'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '绿豆汤',
            effect: '清热解暑，宁心降火',
            ingredients: ['绿豆 150g', '冰糖 50g', '清水 1200ml', '陈皮 1小片'],
            steps: ['绿豆提前浸泡2小时', '加水大火煮沸', '转小火煮至绿豆开花', '加冰糖搅匀放凉饮用'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '苦菊沙拉',
            effect: '清心泻火，抗氧化',
            ingredients: ['苦菊 200g', '圣女果 10颗', '核桃仁 30g', '油醋汁 2勺'],
            steps: ['苦菊洗净撕成小段', '圣女果对半切开', '核桃仁烤香掰碎', '淋油醋汁拌匀即可'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '红枣桂圆茶',
            effect: '补心养血，安神助眠',
            ingredients: ['红枣 6颗', '桂圆干 10粒', '枸杞 10粒', '红糖适量'],
            steps: ['红枣去核切开', '与桂圆一起入壶', '加热水焖泡10分钟', '加红糖枸杞饮用'],
            season: '冬季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '凉拌苦瓜',
            effect: '清心降火，明目解毒',
            ingredients: ['苦瓜 1根', '蒜末适量', '辣椒油 1勺', '白醋 1勺'],
            steps: ['苦瓜去瓤切薄片', '焯水30秒捞出过冰水', '沥干加蒜末辣椒油', '淋白醋拌匀腌制10分钟'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '小米南瓜粥',
            effect: '养心健脾，补中益气',
            ingredients: ['小米 80g', '南瓜 200g', '红枣 4颗', '清水适量'],
            steps: ['南瓜去皮切小块', '小米淘洗干净', '一起入锅加水大火烧开', '转小火熬30分钟至浓稠'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '西芹百合',
            effect: '清心润肺，降压安神',
            ingredients: ['西芹 200g', '鲜百合 100g', '枸杞 10粒', '盐适量'],
            steps: ['西芹斜切段焯水', '百合掰开洗净', '热锅快炒西芹1分钟', '加百合枸杞翻炒30秒调味'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '冬瓜薏米排骨汤',
            effect: '清热利湿，养心消暑',
            ingredients: ['冬瓜 300g', '薏米 50g', '排骨 300g', '姜片 3片'],
            steps: ['排骨焯水去血沫', '薏米提前浸泡1小时', '所有材料入锅加水炖1小时', '加盐调味即可'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '酸枣仁安神饮',
            effect: '养心安神，改善失眠',
            ingredients: ['酸枣仁 15g', '茯苓 10g', '甘草 3g', '清水 500ml'],
            steps: ['酸枣仁捣碎', '与茯苓甘草一起入锅', '加水煮沸转小火煮20分钟', '过滤取汁睡前温饮'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        }
    ],

    /* ═══════════════ 土 · 脾 · 甘味 ═══════════════ */
    earth: [
        {
            name: '山药小米粥',
            effect: '健脾养胃，温补中气',
            ingredients: ['小米 100g', '铁棍山药 1根', '红枣 5颗', '枸杞少许'],
            steps: ['小米淘洗浸泡', '山药去皮切丁', '大火煮开转小火熬30分钟', '出锅前加枸杞'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '南瓜蒸糕',
            effect: '补中益气，健脾和胃',
            ingredients: ['南瓜 300g', '糯米粉 150g', '红糖 30g', '红枣 5颗'],
            steps: ['南瓜蒸熟压泥', '加糯米粉红糖揉成团', '放入模具摆上红枣', '上锅蒸20分钟'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '红薯银耳羹',
            effect: '润肠通便，益脾养胃',
            ingredients: ['红薯 1个', '银耳 半朵', '冰糖适量', '枸杞少许'],
            steps: ['银耳泡发撕碎煮30分钟', '红薯去皮切块加入', '继续煮15分钟至软烂', '加冰糖枸杞即可'],
            season: '冬季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '四神汤',
            effect: '健脾祛湿，补肾固精',
            ingredients: ['山药 30g', '莲子 20g', '茯苓 15g', '芡实 15g'],
            steps: ['所有药材洗净浸泡30分钟', '加猪肚或排骨同炖', '大火烧开转小火煮1.5小时', '加盐调味即可'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '板栗烧鸡',
            effect: '健脾补肾，强筋壮骨',
            ingredients: ['鸡腿 4个', '板栗 200g', '姜片 5片', '酱油 2勺'],
            steps: ['鸡腿切块焯水', '板栗去壳备用', '热锅炒糖色下鸡块翻炒', '加板栗姜片酱油焖煮25分钟'],
            season: '秋冬',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '莲藕排骨汤',
            effect: '养血健脾，滋阴润燥',
            ingredients: ['莲藕 1节', '排骨 400g', '姜片 3片', '盐适量'],
            steps: ['排骨焯水洗净', '莲藕去皮切厚片', '所有材料入砂锅加水', '大火烧开转小火炖1.5小时'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '糯米红豆饭',
            effect: '健脾利湿，补血养颜',
            ingredients: ['糯米 200g', '红豆 50g', '红枣 6颗', '桂花适量'],
            steps: ['红豆提前浸泡一晚', '糯米泡2小时沥干', '红豆煮至半熟与糯米同蒸', '蒸40分钟撒桂花即可'],
            season: '冬季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '胡萝卜玉米排骨汤',
            effect: '健脾开胃，补气养血',
            ingredients: ['胡萝卜 1根', '甜玉米 1根', '排骨 300g', '姜片 3片'],
            steps: ['排骨焯水去沫', '胡萝卜玉米切段', '所有材料入汤锅加水', '大火烧开转小火煮1小时加盐'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '白扁豆薏米粥',
            effect: '健脾化湿，消暑止泻',
            ingredients: ['白扁豆 30g', '薏米 30g', '大米 80g', '冰糖适量'],
            steps: ['白扁豆薏米提前浸泡3小时', '与大米一起入锅加水', '大火烧开转小火熬40分钟', '加冰糖搅匀即可'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '蜜汁蒸山药',
            effect: '补脾益肺，滋阴固肾',
            ingredients: ['铁棍山药 2根', '蜂蜜 2勺', '蓝莓 10粒', '桂花适量'],
            steps: ['山药去皮切段', '上锅蒸15分钟至熟透', '摆盘淋上蜂蜜', '点缀蓝莓桂花即可'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        }
    ],

    /* ═══════════════ 金 · 肺 · 辛味 ═══════════════ */
    metal: [
        {
            name: '冰糖雪梨银耳羹',
            effect: '润肺止咳，滋阴生津',
            ingredients: ['雪梨 2个', '银耳 半朵', '冰糖适量', '枸杞少许'],
            steps: ['银耳提前泡发撕小朵', '雪梨去核切块', '加水炖煮40分钟', '加冰糖枸杞收汁'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '白萝卜牛腩煲',
            effect: '理气化痰，润肺通便',
            ingredients: ['白萝卜 1根', '牛腩 500g', '八角 2个', '姜片 5片'],
            steps: ['牛腩切块焯水', '白萝卜去皮切滚刀块', '热锅炒牛腩加酱油上色', '加萝卜水没过食材焖煮1.5小时'],
            season: '冬季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '川贝枇杷炖梨',
            effect: '清肺化痰，润喉止咳',
            ingredients: ['雪梨 1个', '川贝母 5g', '枇杷 3个', '冰糖 15g'],
            steps: ['雪梨挖去核做容器', '川贝磨粉填入梨心', '加冰糖盖上梨盖', '隔水蒸40分钟即可'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '百合莲子粥',
            effect: '润肺安神，养阴清热',
            ingredients: ['百合 30g', '莲子 20g', '大米 80g', '冰糖适量'],
            steps: ['莲子去心泡软', '大米百合洗净', '一同入锅加水煮沸', '转小火熬至浓稠加冰糖'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '杏仁豆腐',
            effect: '润肺止咳，美白养颜',
            ingredients: ['甜杏仁 50g', '牛奶 300ml', '琼脂 5g', '糖桂花适量'],
            steps: ['杏仁泡水去皮打浆过滤', '琼脂泡软加热融化', '杏仁浆加牛奶和琼脂液搅匀', '冷藏凝固切块淋糖桂花'],
            season: '夏季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '蜂蜜柚子茶',
            effect: '润肺化痰，清热降火',
            ingredients: ['柚子 1个', '蜂蜜 200g', '冰糖 100g', '盐适量'],
            steps: ['柚子皮切丝用盐搓洗', '果肉掰碎与冰糖同煮', '煮至黏稠放凉加蜂蜜', '装瓶冷藏每次取2勺冲饮'],
            season: '秋冬',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '清炒山药片',
            effect: '补肺健脾，益气养阴',
            ingredients: ['山药 1根', '木耳 50g', '胡萝卜 半根', '蒜片适量'],
            steps: ['山药去皮切片入醋水防变色', '木耳泡发胡萝卜切片', '热锅快炒蒜片爆香', '下山药木耳胡萝卜大火翻炒2分钟'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '罗汉果菊花茶',
            effect: '清肺利咽，生津润燥',
            ingredients: ['罗汉果 1/4个', '杭白菊 5朵', '枸杞 10粒', '热水 500ml'],
            steps: ['罗汉果掰碎与菊花同放杯中', '注入沸水', '加盖焖泡8分钟', '加枸杞饮用'],
            season: '四季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '秋藕炖猪蹄',
            effect: '滋阴润肺，美容养颜',
            ingredients: ['莲藕 1节', '猪蹄 1只', '红枣 5颗', '姜片 5片'],
            steps: ['猪蹄剁块焯水去腥', '莲藕切厚片', '所有材料入砂锅加水', '大火烧开转小火炖2小时加盐'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        },
        {
            name: '银耳雪梨露',
            effect: '润肺养颜，清热生津',
            ingredients: ['银耳 1朵', '雪梨 1个', '枸杞 15粒', '冰糖 30g'],
            steps: ['银耳泡发煮至软糯', '雪梨切丁加入', '加冰糖煮10分钟', '放凉后用料理机打成露状'],
            season: '秋季',
            cps_link: 'http://dpurl.cn/DBpDSK1z'
        }
    ],

    /* ═══════════════ 水 · 肾 · 咸味 ═══════════════ */
    water: [
        {
            name: '核桃黑芝麻糊',
            effect: '补肾益精，乌发养颜',
            ingredients: ['核桃仁 50g', '黑芝麻 30g', '糯米粉 20g', '蜂蜜适量'],
            steps: ['核桃黑芝麻小火炒香', '放入料理机打粉', '加糯米粉和热水搅匀', '淋蜂蜜即可'],
            season: '冬季',
            cps_link: '#'
        },
        {
            name: '黑豆排骨汤',
            effect: '补肾强骨，活血利水',
            ingredients: ['黑豆 100g', '排骨 400g', '姜片 5片', '陈皮 1片'],
            steps: ['黑豆提前浸泡一晚', '排骨焯水去沫', '所有材料入锅加水', '大火烧开转小火炖1.5小时加盐'],
            season: '冬季',
            cps_link: '#'
        },
        {
            name: '韭菜虾仁炒蛋',
            effect: '温肾壮阳，补钙强身',
            ingredients: ['韭菜 150g', '虾仁 100g', '鸡蛋 2个', '姜丝适量'],
            steps: ['虾仁料酒腌制5分钟', '鸡蛋炒散盛出', '爆香姜丝下虾仁炒变色', '加韭菜鸡蛋大火快炒30秒'],
            season: '春季',
            cps_link: '#'
        },
        {
            name: '板栗炖乌鸡',
            effect: '补肾益气，养血调经',
            ingredients: ['乌鸡 半只', '板栗 150g', '红枣 6颗', '姜片 5片'],
            steps: ['乌鸡剁块焯水', '板栗去壳备用', '所有材料入砂锅加水', '大火烧开转小火炖1.5小时'],
            season: '秋冬',
            cps_link: '#'
        },
        {
            name: '黑米八宝粥',
            effect: '补肾养血，滋阴益气',
            ingredients: ['黑米 50g', '红豆 30g', '花生 20g', '红枣桂圆各适量'],
            steps: ['黑米红豆提前浸泡4小时', '所有材料入锅加水', '大火煮沸转小火熬1小时', '加冰糖搅匀即可'],
            season: '冬季',
            cps_link: '#'
        },
        {
            name: '枸杞羊肉汤',
            effect: '温肾暖阳，益精补血',
            ingredients: ['羊肉 300g', '枸杞 20粒', '当归 5g', '姜片 5片'],
            steps: ['羊肉切块焯水去膻', '加姜片当归炖煮1小时', '出锅前加枸杞煮5分钟', '加盐调味即可'],
            season: '冬季',
            cps_link: '#'
        },
        {
            name: '海带豆腐味噌汤',
            effect: '补肾利水，软坚散结',
            ingredients: ['海带结 100g', '嫩豆腐 1盒', '味噌 2勺', '葱花适量'],
            steps: ['海带洗净切段', '豆腐切小方块', '水开后下海带煮5分钟再加豆腐', '关火前化入味噌撒葱花'],
            season: '四季',
            cps_link: '#'
        },
        {
            name: '桑葚蜂蜜饮',
            effect: '滋阴补肾，乌发明目',
            ingredients: ['干桑葚 30g', '蜂蜜 2勺', '枸杞 10粒', '热水 400ml'],
            steps: ['桑葚洗净入杯', '加枸杞注入热水', '焖泡10分钟', '放温后加蜂蜜搅匀饮用'],
            season: '春夏',
            cps_link: '#'
        },
        {
            name: '杜仲猪腰汤',
            effect: '补肾壮腰，强筋健骨',
            ingredients: ['猪腰 1对', '杜仲 15g', '枸杞 15粒', '姜片 5片'],
            steps: ['猪腰剖开去白筋切花刀', '焯水去腥捞出', '杜仲姜片入锅加水煮30分钟', '下猪腰枸杞煮10分钟调味'],
            season: '冬季',
            cps_link: '#'
        },
        {
            name: '芝麻核桃红枣球',
            effect: '补肾健脑，养血安神',
            ingredients: ['黑芝麻 50g', '核桃仁 50g', '红枣 8颗', '蜂蜜 2勺'],
            steps: ['黑芝麻核桃小火炒香打碎', '红枣去核切碎混入', '加蜂蜜搅拌揉成小球', '冷藏定型每日2-3颗'],
            season: '四季',
            cps_link: '#'
        }
    ]
};
